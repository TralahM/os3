/*
 * =====================================================================================
 *
 *       Filename:  crc.h
 *
 *    Description: Cyclic Rendundacy Check 32 bits
 *
 *
 *       Compiler:  gcc
 *
 * =====================================================================================
 */
unsigned int crc32(unsigned char* message);
